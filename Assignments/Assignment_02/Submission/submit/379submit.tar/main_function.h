int check_prgm(char* prgm);
int check_argv_number(int argc);
int check_cont_num(char* nSwitch);
int check_sw_num(char* sw);
