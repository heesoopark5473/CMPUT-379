int controller(int nSwitch);
