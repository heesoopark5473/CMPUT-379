int         create_switch_fifo(int nSwitch);
int         print_list_quit_cont(int nSwitch);
char*       fifo_name(int read, int write);
char*       store_swi_info(char* message);