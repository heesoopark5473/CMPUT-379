int switch_sdn(char* swi, char* trafficFile, char* swj, char* swk, char* IP_range);
